// Fungsi bersama untuk halaman: kategori, search, cart, checkout, login, register

function showToast(title, message) {
  document.getElementById('toast-title').textContent = title;
  document.getElementById('toast-body').textContent = message;
  $('#siteToast').toast('show');
}

function formatRp(angka) {
  return 'Rp ' + angka.toLocaleString('id-ID');
}

// Wishlist di kartu produk
document.addEventListener('click', function (e) {
  var btn = e.target.closest('.btn-wishlist');
  if (btn) {
    btn.classList.toggle('active');
    showToast('Wishlist', btn.classList.contains('active') ? 'Ditambahkan ke wishlist.' : 'Dihapus dari wishlist.');
  }
  var eye = e.target.closest('[data-toggle-pass]');
  if (eye) {
    var input = eye.parentElement.querySelector('input');
    input.type = input.type === 'password' ? 'text' : 'password';
  }
});

// Dropdown pencarian di header
var searchInput = document.getElementById('searchInput');
var searchPanel = document.getElementById('searchPanel');
if (searchInput) {
  searchInput.addEventListener('focus', function () { searchPanel.classList.add('open'); });
  document.addEventListener('click', function (e) {
    if (!e.target.closest('.header-search-box')) searchPanel.classList.remove('open');
  });
  searchInput.form.addEventListener('submit', function (e) {
    e.preventDefault();
    location.href = 'search.html?q=' + encodeURIComponent(searchInput.value);
  });
}

// Halaman search: hasil atau kosong
if (document.getElementById('resultsView')) {
  var q = (new URLSearchParams(location.search).get('q') || 'oversized tee').trim();
  if (q.toLowerCase().indexOf('tee') === -1 && q.toLowerCase().indexOf('shirt') === -1) {
    document.getElementById('resultsView').classList.add('d-none');
    document.getElementById('emptyView').classList.remove('d-none');
    document.getElementById('emptyQuery').textContent = q.toUpperCase();
  } else {
    document.getElementById('queryText').textContent = q.toUpperCase();
  }
  if (searchInput) searchInput.value = q;
}

// Halaman cart: jumlah, hapus, total
var cartList = document.getElementById('cartList');
if (cartList) {
  function hitungCart() {
    var total = 0, jumlah = 0;
    cartList.querySelectorAll('.cart-row').forEach(function (row) {
      var qty = parseInt(row.querySelector('.qty-input').value, 10);
      total += parseInt(row.dataset.price, 10) * qty;
      jumlah += qty;
    });
    document.getElementById('cartSub').textContent = formatRp(total);
    document.getElementById('cartTotal').textContent = formatRp(total);
    document.getElementById('subCount').textContent = jumlah;
    document.getElementById('cartCount').textContent = jumlah + ' items in your cart';
  }
  cartList.addEventListener('click', function (e) {
    var row = e.target.closest('.cart-row');
    if (!row) return;
    var step = e.target.closest('[data-qty]');
    if (step) {
      var input = row.querySelector('.qty-input');
      input.value = Math.max(1, parseInt(input.value, 10) + parseInt(step.dataset.qty, 10));
    }
    if (e.target.closest('.cart-remove')) row.remove();
    hitungCart();
  });
}

// Halaman checkout: ongkir dan tombol pesan
var checkoutForm = document.getElementById('checkoutForm');
if (checkoutForm) {
  var subtotal = 1547000;
  checkoutForm.querySelectorAll('input[name="ship"]').forEach(function (radio) {
    radio.addEventListener('change', function () {
      var ongkir = parseInt(radio.value, 10);
      document.getElementById('shipCost').textContent = formatRp(ongkir);
      document.getElementById('grandTotal').textContent = formatRp(subtotal + ongkir);
    });
  });
  checkoutForm.addEventListener('submit', function (e) {
    e.preventDefault();
    if (checkoutForm.checkValidity()) {
      showToast('Pesanan Berhasil', 'Terima kasih! Pesanan Anda sedang diproses.');
    } else {
      showToast('Data belum lengkap', 'Lengkapi informasi pengiriman terlebih dahulu.');
    }
  });
}

// Halaman login & register
var authForm = document.getElementById('authForm');
if (authForm) {
  authForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var pw = authForm.querySelectorAll('input[type="password"]');
    if (pw.length === 2 && pw[0].value !== pw[1].value) {
      showToast('Password tidak sama', 'Konfirmasi password harus sama.');
      return;
    }
    showToast('NOIRÉ', 'Berhasil! Selamat datang.');
  });
}
